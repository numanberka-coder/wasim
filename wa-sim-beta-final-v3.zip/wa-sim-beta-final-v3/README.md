# WhatsApp Simülatör — Modüler Yapı

Orijinal tek dosyalı `whatsapp-simulator-asama1.html` → **27 dosya** modüler yapıya dönüştürüldü.

---

## 📁 Klasör Yapısı

```
wa-simulator/
├── index.html               ← Ana giriş noktası
│
├── css/
│   ├── variables.css        ← CSS değişkenleri (:root)
│   ├── base.css             ← Reset, tipografi, genel stiller
│   ├── components.css       ← Butonlar, inputlar, accordion, kart vb.
│   ├── layout.css           ← Sol panel & sahne düzeni
│   ├── panels.css           ← Panel sekmeler, kişi listesi, editör
│   ├── phone.css            ← Telefon önizleme stilleri
│   └── responsive.css       ← Medya sorguları (tablet/mobil)
│
└── js/
    ├── utils.js             ← DOM yardımcıları, tarih/saat, dosya işlemi
    ├── config.js            ← Sabitler, DEFAULT_STATE, renk havuzu, şablonlar
    ├── state.js             ← Reaktif durum yönetimi (StateManager)
    ├── storage.js           ← LocalStorage okuma/yazma, dosya dışa/içe aktarma
    │
    ├── ui/
    │   ├── toast.js         ← Bildirim sistemi (showSuccess, showError)
    │   ├── validation.js    ← Form doğrulama (markInvalid, clearInvalid)
    │   ├── tabs.js          ← Sekme navigasyonu
    │   ├── accordion.js     ← Açılır/kapanır bölümler
    │   └── forms.js         ← Dosya seçici, range, checkbox bileşenleri
    │
    ├── phone/
    │   ├── header.js        ← Chat başlığı (isim, avatar, durum)
    │   ├── statusbar.js     ← Durum çubuğu (saat, batarya)
    │   ├── wallpaper.js     ← Duvar kağıdı yönetimi
    │   ├── typography.js    ← Font boyutu, satır aralığı, balon boyutu
    │   └── messages.js      ← Mesaj oluşturma ve render
    │
    ├── features/
    │   ├── script-parser.js ← Script metin → olay listesi dönüşümü
    │   ├── script-builder.js← Sürükle-bırak blok düzenleyici + şablonlar
    │   ├── people.js        ← Kişi ekleme/düzenleme/silme
    │   └── player.js        ← Senaryo oynatıcı (play/pause/step/reset)
    │
    └── app.js               ← Uygulama başlatıcı (init, event bağlama)
```

---

## 🚀 Kullanım

Sadece `index.html` dosyasını tarayıcıda açın. Sunucu gerekmez.

```bash
# Chrome ile doğrudan aç
open wa-simulator/index.html
```

---

## ✏️ Geliştirme İpuçları

| Değiştirmek istediğin | Düzenle |
|---|---|
| Renkler / boşluklar | `css/variables.css` |
| Mesaj baloncuğu görünümü | `css/phone.css` |
| Varsayılan kişiler | `js/config.js` → `DEFAULT_PEOPLE` |
| Senaryo komutları (yeni `@komut`) | `js/features/script-parser.js` |
| Oynatıcı davranışı | `js/features/player.js` |
| LocalStorage anahtarı | `js/config.js` → `CONFIG.STORAGE_KEY` |
| Yeni sekme ekle | `js/ui/tabs.js` + `index.html` |

---

## 📦 Orijinal Dosya

`whatsapp-simulator-asama1.html` → 7.119 satır, tek dosya  
Bu yapı → **27 dosya**, her biri bağımsız düzenlenebilir
