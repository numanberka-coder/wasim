/* ========================================
   STORAGE - LocalStorage Operations
   ======================================== */




/**
 * Storage Manager
 */
const storage = {
  /**
   * Save state to localStorage (debounced)
   */
  save: debounce(() => {
    try {
      const data = state.export();
      localStorage.setItem(CONFIG.STORAGE_KEY, JSON.stringify(data));
      console.log('💾 State saved');
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  }, 1000),

  /**
   * Load state from localStorage
   */
  load() {
    try {
      const raw = localStorage.getItem(CONFIG.STORAGE_KEY);
      if (!raw) return false;

      const data = safeJsonParse(raw);
      if (!data) return false;

      state.import(data);
      console.log('📂 State loaded');
      return true;
    } catch (e) {
      console.warn('LocalStorage load error:', e);
      return false;
    }
  },

  /**
   * Clear localStorage
   */
  clear() {
    try {
      localStorage.removeItem(CONFIG.STORAGE_KEY);
      console.log('🗑️ Storage cleared');
    } catch (e) {
      console.warn('LocalStorage clear error:', e);
    }
  },

  /**
   * Export state to JSON file
   */
  exportToFile() {
    const data = state.export();
    const json = JSON.stringify(data, null, 2);
    const filename = `whatsapp_scenario_${Date.now()}.json`;
    downloadFile(json, filename, 'application/json');
    return filename;
  },

  /**
   * Import state from JSON file
   */
  async importFromFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = () => {
        try {
          const data = JSON.parse(reader.result);
          state.import(data);
          storage.save();
          resolve(data);
        } catch (e) {
          reject(new Error('Geçersiz JSON dosyası: ' + e.message));
        }
      };

      reader.onerror = () => {
        reject(new Error('Dosya okunamadı'));
      };

      reader.readAsText(file);
    });
  },

  /**
   * Check if data exists
   */
  hasData() {
    return !!localStorage.getItem(CONFIG.STORAGE_KEY);
  },

  /**
   * Get storage size
   */
  getSize() {
    const data = localStorage.getItem(CONFIG.STORAGE_KEY);
    if (!data) return 0;
    return new Blob([data]).size;
  }
};

/**
 * Auto-save on state changes
 */
function initAutoSave() {
  // Subscribe to state changes
  state.subscribe(() => {
    storage.save();
  });

  // Periodic save as backup
  setInterval(() => {
    storage.save();
  }, CONFIG.AUTO_SAVE_INTERVAL);

  console.log('⚡ Auto-save initialized');
}
